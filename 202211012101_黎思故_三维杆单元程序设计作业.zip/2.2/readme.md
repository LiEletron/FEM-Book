# 三维杆单元刚度矩阵与应力计算程序

## 项目简介

本程序基于有限元法实现三维杆单元（空间桁架单元）的基本计算功能，包括：

* 单元长度计算
* 方向余弦计算
* 三维杆单元刚度矩阵计算
* 单元应变计算
* 单元应力计算
* 单元轴力计算
* 刚度矩阵性质验证
* 刚度矩阵物理意义验证

程序使用 Python 编写，并依赖 NumPy 进行矩阵运算。

---

## 文件说明

```text
truss3d.py          主程序源代码
README.md           运行说明
报告.pdf            作业报告
result_screenshot 1  算例1运行结果截图
result_screenshot 2  算例2运行结果截图
```

## 程序主要函数

### truss3d_element_stiffness()

计算三维杆单元长度、方向余弦及刚度矩阵。

```python
L, direction_cosines, Ke =
truss3d_element_stiffness(
    x1, x2, E, A
)
```

参数：

```text
x1 : 节点1坐标 [x,y,z]
x2 : 节点2坐标 [x,y,z]
E  : 弹性模量(Pa)
A  : 截面积(m²)
```

返回：

```text
L : 单元长度
(cx,cy,cz) : 方向余弦
Ke : 6×6刚度矩阵
```

---

### truss3d_element_stress()

根据节点位移计算应变、应力和轴力。

```python
epsilon, sigma, N =
truss3d_element_stress(
    x1, x2, E, A, de
)
```

参数：

```text
de = [u1,v1,w1,u2,v2,w2]
```

返回：

```text
epsilon : 应变
sigma   : 应力(Pa)
N       : 轴力(N)
```

---

## 输入单位

程序统一采用国际单位制（SI）：

```text
长度：m
力：N
应力：Pa
弹性模量：Pa
截面积：m²
```

例如：

```python
E = 210e9
A = 2.0e-4
```

表示：

```text
E = 210 GPa
A = 0.0002 m²
```

---

## 退化单元检查

程序对节点重合情况进行了检查。

若：

```text
L ≈ 0
```

程序将输出错误信息：

```text
错误：两个节点重合，单元长度为零。
```

并停止计算。

---

## 验证结果

### 算例1

```text
L = 2 m
方向余弦 = (1,0,0)
ε = 5.0×10⁻⁴
σ = 100 MPa
N = 10000 N
```

### 算例2

```text
L = 3 m
方向余弦 = (1/3,2/3,2/3)
ε = 1.0×10⁻³
σ = 210 MPa
N = 42000 N
```

结果与理论解一致。

---

## 作者信息

课程：计算力学

作业名称：三维杆单元刚度矩阵与应⼒计
算

作者：黎思故

学号：202211012101
