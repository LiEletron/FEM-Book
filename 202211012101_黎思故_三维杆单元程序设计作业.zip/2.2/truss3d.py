import numpy as np


# =====================================================
# 三维杆单元刚度矩阵
# =====================================================
def truss3d_element_stiffness(x1, x2, E, A):
    x1 = np.array(x1, dtype=float)
    x2 = np.array(x2, dtype=float)

    delta = x2 - x1
    L = np.linalg.norm(delta)

    # 退化单元检查
    if L < 1e-12:
        raise ValueError("错误：两个节点重合，单元长度为零。")

    cx, cy, cz = delta / L

    EA_L = E * A / L

    c = np.array([cx, cy, cz])

    k3 = EA_L * np.outer(c, c)

    Ke = np.zeros((6, 6))

    Ke[:3, :3] = k3
    Ke[:3, 3:] = -k3
    Ke[3:, :3] = -k3
    Ke[3:, 3:] = k3

    return L, (cx, cy, cz), Ke


# =====================================================
# 应变、应力、轴力计算
# =====================================================
def truss3d_element_stress(x1, x2, E, A, de):

    x1 = np.array(x1, dtype=float)
    x2 = np.array(x2, dtype=float)
    de = np.array(de, dtype=float)

    delta = x2 - x1
    L = np.linalg.norm(delta)

    if L < 1e-12:
        raise ValueError("错误：两个节点重合，单元长度为零。")

    cx, cy, cz = delta / L

    direction = np.array([cx, cy, cz])

    delta_L = np.dot(de[3:] - de[:3], direction)

    epsilon = delta_L / L

    sigma = E * epsilon

    N = sigma * A

    return epsilon, sigma, N


# =====================================================
# 主程序
# =====================================================
if __name__ == "__main__":

    # =================================================
    # 算例1
    # =================================================
    print("=" * 60)
    print("算例1：沿x轴的一维杆单元")
    print("=" * 60)

    x1 = [0.0, 0.0, 0.0]
    x2 = [2.0, 0.0, 0.0]

    E = 200e9
    A = 1.0e-4

    de = [0.0, 0.0, 0.0,
          1.0e-3, 0.0, 0.0]

    L, (cx, cy, cz), Ke = truss3d_element_stiffness(
        x1, x2, E, A
    )

    epsilon, sigma, N = truss3d_element_stress(
        x1, x2, E, A, de
    )

    print(f"单元长度 L = {L:.6f} m")
    print(f"方向余弦 = ({cx:.6f}, {cy:.6f}, {cz:.6f})")

    print("\n刚度矩阵 Ke:")
    print(Ke)

    print(f"\n应变 ε = {epsilon:.6e}")
    print(f"应力 σ = {sigma:.6e} Pa")
    print(f"应力 σ = {sigma/1e6:.3f} MPa")
    print(f"轴力 N = {N:.3f} N")

    # =================================================
    # 算例2
    # =================================================
    print("\n")
    print("=" * 60)
    print("算例2：空间任意方向杆单元")
    print("=" * 60)

    x1 = [0.0, 0.0, 0.0]
    x2 = [1.0, 2.0, 2.0]

    E = 210e9
    A = 2.0e-4

    de = [0.0, 0.0, 0.0,
          1.0e-3, 2.0e-3, 2.0e-3]

    L, (cx, cy, cz), Ke = truss3d_element_stiffness(
        x1, x2, E, A
    )

    epsilon, sigma, N = truss3d_element_stress(
        x1, x2, E, A, de
    )

    print(f"\n单元长度 L = {L:.6f} m")
    print(f"方向余弦 = ({cx:.6f}, {cy:.6f}, {cz:.6f})")

    # -------------------------------------------------
    # 对称性验证
    # -------------------------------------------------
    print("\n【刚度矩阵对称性验证】")

    symmetric = np.allclose(Ke, Ke.T)

    print("Ke是否对称：", symmetric)

    # -------------------------------------------------
    # 刚体位移验证
    # -------------------------------------------------
    print("\n【刚体位移验证】")

    de_rigid = [1, 0, 0,
                1, 0, 0]

    eps_rigid, sig_rigid, N_rigid = \
        truss3d_element_stress(
            x1, x2, E, A, de_rigid
        )

    print("刚体平移应变 =", eps_rigid)
    print("刚体平移轴力 =", N_rigid)

    # -------------------------------------------------
    # 特征值验证
    # -------------------------------------------------
    print("\n【特征值分析】")

    eigvals = np.linalg.eigvals(Ke)

    eigvals = np.real(eigvals)

    print("特征值：")

    for ev in eigvals:
        print(f"{ev:.6e}")

    non_negative = np.all(eigvals >= -1e-8)

    print("\n所有特征值非负：", non_negative)

    zero_count = np.sum(np.abs(eigvals) < 1e-8)

    print("零特征值个数 =", zero_count)

    rank = np.linalg.matrix_rank(Ke)

    print("矩阵秩 rank =", rank)

    print("\n说明：")
    print("三维杆单元仅具有轴向刚度。")
    print("6个自由度中只有1个变形模式具有刚度。")
    print("因此矩阵秩为1，存在5个零特征值。")
    print("所以单个自由杆单元刚度矩阵为奇异矩阵。")

    # -------------------------------------------------
    # 力学响应
    # -------------------------------------------------
    print("\n【应变应力轴力】")

    print(f"应变 ε = {epsilon:.6e}")
    print(f"应力 σ = {sigma/1e6:.3f} MPa")
    print(f"轴力 N = {N:.3f} N")

    # =================================================
    # 任务4
    # =================================================
    print("\n")
    print("=" * 60)
    print("刚度矩阵物理意义验证")
    print("=" * 60)

    de_col = np.array([
        1, 0, 0,
        0, 0, 0
    ])

    Fe = Ke @ de_col

    print("\n位移向量 de =")
    print(de_col)

    print("\nFe = Ke * de")

    print(Fe)

    print("\nKe第一列 =")

    print(Ke[:, 0])

    same = np.allclose(
        Fe,
        Ke[:, 0]
    )

    print("\nFe 是否等于 Ke 第一列？", same)

    print("\n物理意义：")
    print("当第1个自由度产生单位位移，")
    print("其余自由度保持不动时，")
    print("产生的节点力列阵恰好等于刚度矩阵第1列。")
    print("因此刚度矩阵第j列表示：")
    print("第j个自由度产生单位位移时")
    print("各自由度产生的节点力。")

    print("\n")
    print("=" * 60)
    print("程序运行结束")
    print("=" * 60)