import numpy as np
import matplotlib.pyplot as plt

# =====================================================
# SUPG 参数
# =====================================================
def alpha_supg(Pe):
    """返回 coth(Pe) - 1/Pe"""
    if abs(Pe) < 1e-8:
        return 0.0
    return 1.0 / np.tanh(Pe) - 1.0 / Pe


# =====================================================
# 单元矩阵
# =====================================================
def element_matrix(kappa, v, le, alpha):
    """返回两节点线性单元的 2 x 2 对流扩散单元矩阵"""

    kappa_bar = kappa + alpha * v * le / 2.0

    diffusion = (kappa_bar / le) * np.array(
        [[1, -1],
         [-1, 1]],
        dtype=float
    )

    convection = (v / 2.0) * np.array(
        [[-1, 1],
         [-1, 1]],
        dtype=float
    )

    return diffusion + convection


# =====================================================
# 精确解
# =====================================================
def exact_solution(x, v, kappa, L):

    numerator = np.expm1(v * x / kappa)
    denominator = np.expm1(v * L / kappa)

    return numerator / denominator


# =====================================================
# 有限元求解
# =====================================================
def solve_advection_diffusion(
        nel,
        L,
        v,
        kappa,
        alpha):
    """返回节点坐标 x、数值解 theta、精确解 theta_exact"""

    nn = nel + 1
    le = L / nel

    x = np.linspace(0, L, nn)

    K = np.zeros((nn, nn))

    # -------------------------
    # 组装总体矩阵
    # -------------------------
    for e in range(nel):

        Ke = element_matrix(
            kappa,
            v,
            le,
            alpha
        )

        nodes = [e, e + 1]

        for i in range(2):
            for j in range(2):
                K[nodes[i], nodes[j]] += Ke[i, j]

    # -------------------------
    # 边界条件
    # theta(0)=0
    # theta(L)=1
    # -------------------------
    theta = np.zeros(nn)

    theta[0] = 0.0
    theta[-1] = 1.0

    Kii = K[1:-1, 1:-1]

    rhs = (
        -K[1:-1, 0] * theta[0]
        -K[1:-1, -1] * theta[-1]
    )

    theta[1:-1] = np.linalg.solve(Kii, rhs)

    theta_exact = exact_solution(
        x,
        v,
        kappa,
        L
    )

    return x, theta, theta_exact, K


# =====================================================
# 主程序
# =====================================================
def main():

    nel = 20
    L = 1.0
    v = 1.0

    print("=" * 60)
    print("1D Advection-Diffusion FEM")
    print("=" * 60)

    for Pe in [0.1, 3.0]:

        print("\n")
        print("=" * 60)
        print(f"Pe = {Pe}")
        print("=" * 60)

        le = L / nel

        kappa = v * le / (2.0 * Pe)

        print("kappa =", kappa)

        alpha_opt = alpha_supg(Pe)

        methods = {
            "Galerkin": 0.0,
            "Upwind": 1.0,
            "SUPG": alpha_opt
        }

        plt.figure(figsize=(8, 5))

        for method, alpha in methods.items():

            x, theta, theta_exact, K = \
                solve_advection_diffusion(
                    nel,
                    L,
                    v,
                    kappa,
                    alpha
                )

            max_error = np.max(
                np.abs(theta - theta_exact)
            )

            print(
                f"{method:10s} "
                f"alpha={alpha:.6f} "
                f"max_error={max_error:.6e}"
            )

            plt.plot(
                x,
                theta,
                marker='o',
                label=method
            )

        plt.plot(
            x,
            theta_exact,
            'k--',
            linewidth=2,
            label='Exact'
        )

        plt.xlabel("x")
        plt.ylabel("theta")
        plt.title(f"Pe = {Pe}")

        plt.grid(True)
        plt.legend()

        plt.tight_layout()

        plt.savefig(
            f"Pe_{Pe}.png",
            dpi=300
        )

        plt.show()

        # -------------------------------------------------
        # Pe=3.0时分析矩阵性质
        # -------------------------------------------------
        if abs(Pe - 3.0) < 1e-12:

            print("\n")
            print("=" * 60)
            print("Galerkin Global Matrix")
            print("=" * 60)

            _, _, _, Kgal = solve_advection_diffusion(
                nel,
                L,
                v,
                kappa,
                0.0
            )

            np.set_printoptions(
                precision=3,
                suppress=True
            )

            print(Kgal)

            symmetric = np.allclose(
                Kgal,
                Kgal.T
            )

            print("\nMatrix symmetric ?")
            print(symmetric)

            interior = Kgal[1:-1, 1:-1]

            eigvals = np.linalg.eigvals(interior)

            min_real = np.min(
                np.real(eigvals)
            )

            print("\nMinimum real eigenvalue:")
            print(min_real)

            if min_real > 0:
                print("Positive definite (approximately)")
            else:
                print("Not positive definite")


if __name__ == "__main__":
    main()