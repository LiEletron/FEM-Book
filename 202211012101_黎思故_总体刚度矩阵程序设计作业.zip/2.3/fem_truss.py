import numpy as np
import json
import sys


# =====================================================
# 读取输入文件
# =====================================================
def read_input(filename):

    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)


# =====================================================
# 一维杆单元
# =====================================================
def bar1d_element(EA_L):

    return EA_L * np.array([
        [1.0, -1.0],
        [-1.0, 1.0]
    ])


# =====================================================
# 二维桁架单元
# =====================================================
def truss2d_element(x1, y1, x2, y2, E, A):

    dx = x2 - x1
    dy = y2 - y1

    L = np.sqrt(dx**2 + dy**2)

    if L < 1e-12:
        raise ValueError("单元长度为0")

    c = dx / L
    s = dy / L

    coeff = E * A / L

    Ke = coeff * np.array([
        [ c*c,  c*s, -c*c, -c*s],
        [ c*s,  s*s, -c*s, -s*s],
        [-c*c, -c*s,  c*c,  c*s],
        [-c*s, -s*s,  c*s,  s*s]
    ])

    return L, c, s, Ke


# =====================================================
# LM矩阵
# =====================================================
def generate_LM(IEN, ndof):

    nel = len(IEN)

    if ndof == 1:

        LM = np.zeros((2, nel), dtype=int)

        for e, (n1, n2) in enumerate(IEN):

            LM[:, e] = [
                n1,
                n2
            ]

    else:

        LM = np.zeros((4, nel), dtype=int)

        for e, (n1, n2) in enumerate(IEN):

            LM[:, e] = [
                2*n1,
                2*n1+1,
                2*n2,
                2*n2+1
            ]

    return LM


# =====================================================
# 总体刚度矩阵组装
# =====================================================
def assemble_global_K(case):

    ndof = case["ndof"]
    nnp = case["nnp"]

    total_dof = nnp * ndof

    K = np.zeros((total_dof, total_dof))

    IEN = [
        (e[0]-1, e[1]-1)
        for e in case["IEN"]
    ]

    LM = generate_LM(IEN, ndof)

    # -------------------------------
    # Case1 一维杆
    # -------------------------------
    if ndof == 1:

        EA_L = case["EA_L"]

        for e, (n1, n2) in enumerate(IEN):

            Ke = bar1d_element(EA_L[e])

            lm = [n1, n2]

            for a in range(2):
                for b in range(2):

                    K[lm[a], lm[b]] += Ke[a, b]

    # -------------------------------
    # Case2 二维桁架
    # -------------------------------
    elif ndof == 2:

        nodes = list(
            zip(
                case["x"],
                case["y"]
            )
        )

        E = case["E"]
        A = case["CArea"]

        for e, (n1, n2) in enumerate(IEN):

            x1, y1 = nodes[n1]
            x2, y2 = nodes[n2]

            _, _, _, Ke = truss2d_element(
                x1, y1,
                x2, y2,
                E[e],
                A[e]
            )

            lm = [
                2*n1,
                2*n1+1,
                2*n2,
                2*n2+1
            ]

            for a in range(4):
                for b in range(4):

                    K[lm[a], lm[b]] += Ke[a, b]

    return K, LM, IEN


# =====================================================
# 求解
# =====================================================
def solve_system(K,
                 force,
                 fixed_dof,
                 fixed_value):

    total_dof = len(force)

    d = np.zeros(total_dof)

    fixed = np.array(fixed_dof)

    d[fixed] = fixed_value

    free = np.setdiff1d(
        np.arange(total_dof),
        fixed
    )

    Kff = K[np.ix_(free, free)]

    Kfe = K[np.ix_(free, fixed)]

    rhs = force[free] - Kfe @ d[fixed]

    d[free] = np.linalg.solve(
        Kff,
        rhs
    )

    reaction = K @ d - force

    return d, reaction


# =====================================================
# 后处理
# =====================================================
def postprocess(case, IEN, d):

    ndof = case["ndof"]

    results = []

    # -------------------------------
    # 一维杆
    # -------------------------------
    if ndof == 1:

        for e, (n1, n2) in enumerate(IEN):

            EA_L = case["EA_L"][e]

            strain = d[n2] - d[n1]

            stress = strain

            axial_force = EA_L * strain

            results.append({
                "element": e+1,
                "stress": stress,
                "axial_force": axial_force
            })

    # -------------------------------
    # 二维桁架
    # -------------------------------
    else:

        nodes = list(
            zip(
                case["x"],
                case["y"]
            )
        )

        E = case["E"]
        A = case["CArea"]

        for e, (n1, n2) in enumerate(IEN):

            x1, y1 = nodes[n1]
            x2, y2 = nodes[n2]

            L, c, s, _ = truss2d_element(
                x1, y1,
                x2, y2,
                E[e],
                A[e]
            )

            de = np.array([
                d[2*n1],
                d[2*n1+1],
                d[2*n2],
                d[2*n2+1]
            ])

            strain = (
                np.array([-c, -s, c, s])
                @ de
            ) / L

            stress = E[e] * strain

            axial_force = stress * A[e]

            results.append({
                "element": e+1,
                "stress": stress,
                "axial_force": axial_force
            })

    return results


# =====================================================
# 主程序
# =====================================================
if __name__ == "__main__":

    if len(sys.argv) != 2:

        print("用法:")
        print("python fem_truss.py case1.json")
        print("python fem_truss.py case2.json")
        sys.exit()

    case = read_input(sys.argv[1])

    print("=" * 60)
    print(case["Title"])
    print("=" * 60)

    K, LM, IEN = assemble_global_K(case)

    print("\nLM矩阵:")
    print(LM)

    print("\n总体刚度矩阵 K:")
    print(K)

    ndof = case["ndof"]

    total_dof = case["nnp"] * ndof

    force = np.zeros(total_dof)

    for dof, value in zip(
        case["force_dof"],
        case["force_value"]
    ):

        force[dof - 1] = value

    fixed_dof = [
        d-1
        for d in case["fixed_dof"]
    ]

    fixed_value = case["fixed_value"]

    d, reaction = solve_system(
        K,
        force,
        fixed_dof,
        fixed_value
    )

    print("\n节点位移:")
    print(d)

    print("\n约束反力:")
    print(reaction)

    results = postprocess(
        case,
        IEN,
        d
    )

    print("\n单元结果:")

    for r in results:

        print("-"*40)

        print(
            f"单元 {r['element']}"
        )

        print(
            f"应力 = {r['stress']:.6f}"
        )

        print(
            f"轴力 = {r['axial_force']:.6f}"
        )

    print("\n总体刚度矩阵特征值:")

    eig = np.linalg.eigvals(K)

    print(np.real(eig))

    print("\n矩阵秩:")

    print(np.linalg.matrix_rank(K))

    print("\n程序结束")